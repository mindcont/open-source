./start.sh to run the program

to stop the program use the following:

killall node

pkill uv4l


